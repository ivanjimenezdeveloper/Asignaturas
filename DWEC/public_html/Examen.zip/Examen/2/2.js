
//En cada funcion llamada cambio el style del body al color correspondiente
function amarillo(){
document.getElementById("fondo").style.backgroundColor = "yellow";    
}

function verde(){
document.getElementById("fondo").style.backgroundColor = "green";    
}

function rojo(){
document.getElementById("fondo").style.backgroundColor = "red";    
}

function azul(){
document.getElementById("fondo").style.backgroundColor = "blue";    
}

function naranja(){
document.getElementById("fondo").style.backgroundColor = "orange";    
}